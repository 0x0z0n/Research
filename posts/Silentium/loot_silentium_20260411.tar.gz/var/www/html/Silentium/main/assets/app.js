// Wait for DOM to load
document.addEventListener("DOMContentLoaded", () => {

  // Navbar scroll behavior
  const nav = document.getElementById("nav");
  window.addEventListener("scroll", () => {
    if (window.scrollY > 60) {
      nav.classList.add("bg-white/95", "backdrop-blur", "shadow-sm");
    } else {
      nav.classList.remove("bg-white/95", "backdrop-blur", "shadow-sm");
    }
  });

  // Calculator logic
  function calc(amount, term, rate = 4.5) {
    const r = rate / 100 / 12;

    // Safety guard
    if (r === 0 || term === 0) return 0;

    return (
      amount * r * Math.pow(1 + r, term)
    ) / (
      Math.pow(1 + r, term) - 1
    );
  }

  const amount = document.getElementById("amount");
  const term = document.getElementById("term");
  const monthly = document.getElementById("monthly");
  const amountLabel = document.getElementById("amountLabel");
  const termLabel = document.getElementById("termLabel");

  function update() {
    const a = Number(amount.value);
    const t = Number(term.value);

    amountLabel.textContent = `$${a.toLocaleString()}`;
    termLabel.textContent = t;
    monthly.textContent = `$${calc(a, t).toFixed(2)}`;
  }

  amount.addEventListener("input", update);
  term.addEventListener("input", update);

  // Initial render
  update();
});

