ls
cat user.txt
python -v
python --version
python3 --version
nano poc.py
python3 poc.py
git push
cd /home && ls
tuln --s
tuln -ss
ss -tln
exit
